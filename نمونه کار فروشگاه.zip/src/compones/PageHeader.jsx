import React from 'react'
import { Link } from 'react-router-dom'
function PageHeader({title, curPage}) {
    window.addEventListener("load", () => {
        window.scrollTo(0, 0);
    });
  return (
    <div className='pageheader-section'>
        <div className="container">
            <div className="row">
                <div className='col-12'>
                    <div className="pageHeader-content text-center">
                        <h2 className='mb-4' style={{fontSize: "2rem"}}>{title}</h2>
                        <nav aria-label='breadcrumb'>
                            <ol className='breadcrumb justify-content-center'>
                                <li><Link className="breadcrumb-item" to="/" className="me-2"> خانه </Link></li>
                                <li className="breadcrumb-item active" aria-current="page"> / {curPage}</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default PageHeader