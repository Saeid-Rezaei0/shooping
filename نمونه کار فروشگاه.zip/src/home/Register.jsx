import React from 'react';

const subTitle = "رسیدگی کنید";
const title = (
    <h3 className='title text-dark my-3' style={{fontSize:"1.4rem"}}>به کارگاه رایگان یک روزه بپیوندید برای <b>آموزش پیشرفته <span>مدیریت</span></b>در فروش</h3>
);
const desc = "پیشنهاد محدود زمانی";

function Register() {
    return (
        <section className='register-section padding-tb pb-0 rtl'>
            <div className="container">
                <div className="row rol-cols-lg-2 rol-cols-3 align-items-center">
                  
                    <div className="col">
                        <div className='section-wrapper'>
                            <h4>هم اکنون ثبت نام کنید</h4>
                            <form className='register-form'>
                                <input type="text" name='name' placeholder='نام کاربری' className='reg-input shadow' />
                                <input type="email" name='name' placeholder='ایمیل' className='reg-input shadow' />
                                <input type="number" name='name' placeholder='تلفن' className='reg-input shadow' />
                                <button type='submit' className='lab-btn'>
                                    ثبت نام کنید
                                </button>
                            </form>
                        </div>
                    </div>
                    <div className="col ">
                        <div className="section-header" style={{lineHeight: "2rem"}}>
                            <span className='subtitle text-dark hight-2'>{subTitle}</span>
                            {title}
                            <p className='text-dark'>{desc}</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Register;
