import React, { useState } from 'react'
import { Modal, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const CheckOutPage = () => {
    const [show, setShow] = useState(false);
    const [active, setActive] = useState("visa");

    const handleTapChange = (tabID) => {
        setActive(tabID)
    }

    const handleShow = () => setShow(true);
    const handleClose = () => setShow(false);

    return (
        <div className='modalCard'>
            <Button variant='primary' className='py-2 shadow' style={{backgroundColor: "#B1C9EF", color: "#000"}} onClick={handleShow}>پرداخت نهایی</Button>
            <Modal
                show={show}
                onHide={handleClose}
                animation={false}
                centered
                className='rtl'
            >
                <Modal.Header closeButton>
                    <Modal.Title>به یکی از روش های زیر انتخاب کنید</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className='modal-content'>
                        <div className="modal-body">
                            {/* Tab selection */}
                            <ul className="nav nav-tabs">
                                <li className="nav-item">
                                    <Button variant='link' className={`nav-link ${active === "visa" ? "active" : ""}`}
                                        onClick={() => handleTapChange("visa")}>
                                        <img width="80" src="https://repository-images.githubusercontent.com/410418462/1f0e17c2-0624-4d78-afd8-7c44a2195af9" alt="" />
                                    </Button>
                                </li>
                                <li className="nav-item">
                                    <Button variant='link' className={`nav-link ${active === "mastercard" ? "active" : ""}`} onClick={() => handleTapChange("mastercard")}>
                                        <img width="150" src="https://www.paypalobjects.com/digitalassets/c/website/logo/full-text/pp_fc_hl.svg" alt="" />
                                    </Button>
                                </li>
                            </ul>

                            {/* Tab content */}
                            <div className="tab-content">
                                {active === "visa" && (
                                    <div className="tab-pane active">
                                      
                                        {/* Visa payment form content */}
                                        <div class="card mt-3">
                                            <div class="card-body" style={{ textAlign: "right" }}>
                                                <h5 class="card-title mb-4">اطلاعات کارت اعتباری</h5>

                                                <div class="form">
                                                    <div class="mb-3 border-bottom">
                                                        <label for="name" class="form-label">نام دارنده کارت</label>
                                                        <input type="text" class='form-control' id='name' style={{ textAlign: "right" }} placeholder='نام خود را وارد کنید' required />
                                                    </div>

                                                    <div class="mb-3 border-bottom">
                                                        <label for="number" class="form-label">شماره کارت</label>
                                                        <div class="input-group ">
                                                            <input type="text" class='form-control border-right' id='number' style={{ textAlign: "right" }} placeholder='شماره کارت را وارد کنید' required />
                                                            <span class="input-group-text border-left"><i class="icofont-eye"></i></span>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-6 mb-3 border-bottom">
                                                            <label for="expiry" class="form-label">تاریخ انقضا</label>
                                                            <input type="text" class='form-control' id='expiry' placeholder='MM/YY' required />
                                                        </div>
                                                        <div class="col-md-6 mb-3 border-bottom">
                                                            <label for="cvv" class="form-label">CVV</label>
                                                            <input type="text" class='form-control' id='cvv' placeholder='CVV' required />
                                                        </div>
                                                    </div>

                                                    <button type="submit" class="btn btn-primary w-100">ارسال</button>
                                                </div>
                                            </div>
                                        </div>




                                    </div>
                                )}
                                {active === "mastercard" && (
                                    <div className="tab-pane active" style={{ textAlign: "right" }}>
                                        <div className="card my-3">
                                            <div className="card-body">
                                                <h5 className="card-title mb-4">اطلاعات حساب PayPal</h5>
                                                <div className="form">
                                                    <div className="mb-3">
                                                        <label htmlFor="email" className="form-label">آدرس ایمیل PayPal</label>
                                                        <input type="email" style={{ textAlign: "right" }} className='form-control' id='email' placeholder='آدرس ایمیل PayPal را وارد کنید' required />
                                                    </div>

                                                    <div className="mb-3">
                                                        <label htmlFor="password" className="form-label">رمز عبور</label>
                                                        <input type="password" style={{ textAlign: "right" }} className='form-control' id='password' placeholder='رمز عبور خود را وارد کنید' required />
                                                    </div>

                                                    <button type="submit" className="btn btn-primary w-100"> PayPal ورود به حساب </button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                       بسته
                    </Button>
                    <Button variant="primary"  onClick={() => { /* handle payment submission */ }}>
                       پرداخت
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    )
}

export default CheckOutPage;
