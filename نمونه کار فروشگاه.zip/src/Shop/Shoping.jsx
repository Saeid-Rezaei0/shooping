import React, { useState } from 'react'
import PageHeader from '../compones/PageHeader'
import Data from "../products.json"
import ProductCard from './ProductCard'
import Pagenation from './Pagenation'
import Search from './Search'
import ShopCategory from './ShopCategory'
import PopularPost from './PopularPost'
import Tags from './Tags'
import Map from './Map'
import ProductSlider from '../home/SliderProduct'
const shopresult = "نمایش ۰۱ - ۱۲ از ۱۳۹ نتیجه";
function Shoping() {
    const [Gridelist, setGridelist] = useState(false)
    const [product, setproduct] = useState(Data)


    const [currentpage, setcurrentpage] = useState(1)
    const productPage = 12;

    const indexoflastproduct = currentpage * productPage
    const indexofFirstproduct = indexoflastproduct - productPage

    const currentproduct = product.slice(indexofFirstproduct, indexoflastproduct)

    const pagination = (pagebumber) => {
        setcurrentpage(pagebumber)
    }
    const [selectcategory ,setselectcategory] = useState("")
    const menuItem = [...new Set(Data.map((val)=> val.category))]
  
  const filteritem = (current) =>{
    const newItem = Data.filter((newVAl)=> {
        return newVAl.category === current;
    })
    setselectcategory(current)
    setproduct(newItem)
  }
    return (
        <div>
            <PageHeader title="صفحه محصولات" curPage="فروشگاه" />
            {/* shop page */}
            <div className='shop=page padding-tb'>
                <div className="container">
                    <div className="row justify-content-center">
                        <div className='col-lg-8 col-12'>
                            <article>
                                <div className="shop-title d-flex flex-wrap  justify-content-between rtl">                                
                                       <p>{shopresult}</p>
                                       <div className={`product-view-mode  ${Gridelist ? "gridActive" : "listActive"}`}>
                                        <a className='grid' style={{fontSize: "1.5rem"}} onClick={()=> setGridelist(!Gridelist)}>
                                            <i className='icofont-ghost'></i>
                                        </a>
                                        <a className='list m-3' style={{fontSize: "1.5rem"}} onClick={()=> setGridelist(!Gridelist)}>
                                            <i className='icofont-listine-dots'></i>
                                        </a>
                                    </div>
                                </div>

                                <div>
                                <ProductCard  Gridelist={Gridelist} products={currentproduct}/>
                                </div>
                                <Pagenation
                                productPage={productPage}
                                totalproduct= {product.length}
                                Pagenation={pagination}
                                activepage={currentpage}
                                />
                        </article>
                        </div>
                        <div className='col-lg-4 col-12 ' style={{marginTop: "4.2rem"}}>
                            <side>
                                <Search products={product} Gridelist={Gridelist}/>
                                <ShopCategory 
                                filteritem={filteritem}
                                setitem={setproduct}
                                menuItem={menuItem}
                                setproducts={setproduct}
                                selectcategory={selectcategory}
                                />
                            </side>
                            <PopularPost/>
                            <Tags />
                            {/* <Map  /> */}
                        </div>
                    </div>
                </div>
            </div>
            <ProductSlider />
        </div>
    )
}

export default Shoping