import React, { useRef, useState } from 'react';
// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';
// Import Swiper styles
import 'swiper/css';
import 'swiper/css/pagination';
import { Autoplay } from 'swiper/modules';
import Ratting from '../compones/Ratting';
import { Link } from 'react-router-dom';
const ProductData = [
    {
        imgUrl: 'src/assets/images/categoryTab/01.jpg',
        cate: 'کفش',
        title: 'نایک پرمیر ایکس',
        author: 'assets/images/course/author/01.jpg',
        brand: 'نایک',
        price: '580.000 تومان',
        id: 1,
    },
    {
        imgUrl: 'src/assets/images/categoryTab/02.jpg',
        cate: 'کیف',
        title: 'کیف‌های زیبایی',
        author: 'assets/images/course/author/02.jpg',
        brand: 'D&J Bags',
        price: '199.000 تومان',
        id: 2,
    },
    {
        imgUrl: 'src/assets/images/categoryTab/03.jpg',
        cate: 'تلفن‌ها',
        title: 'آیفون 12',
        author: 'src/assets/images/categoryTab/brand/apple.png',
        brand: 'اپل',
        price: '45000.000 تومان',
        id: 3,
    },
    {
        imgUrl: 'src/assets/images/categoryTab/04.jpg',
        cate: 'کیف',
        title: 'کوله‌پشتی مسافرتی Nh100',
        author: 'assets/images/course/author/04.jpg',
        brand: 'گوچی',
        price: '899.000 تومان',
        id: 4,
    },
    {
        imgUrl: 'src/assets/images/categoryTab/05.jpg',
        cate: 'کفش',
        title: 'کفش‌های ورزشی خارجی',
        author: 'assets/images/course/author/05.jpg',
        brand: 'نایک',
        price: '980.000 تومان',
        id: 5,
    },
    {
        imgUrl: 'src/assets/images/categoryTab/06.jpg',
        cate: 'زیبایی',
        title: 'موکیتین حلزونی COSRX',
        author: 'assets/images/course/author/06.jpg',
        brand: 'زارا',
        price: '167.000 تومان',
        id: 6,
    },
    {
        imgUrl: 'src/assets/images/categoryTab/07.jpg',
        cate: 'کیف',
        title: 'کیف چنل Look Less',
        author: 'assets/images/course/author/01.jpg',
        brand: 'گوچی',
        price: '384.000 تومان',
        id: 7,
    },
    {
        imgUrl: 'src/assets/images/categoryTab/08.jpg',
        cate: 'کفش',
        title: 'کفش‌های ورزشی روزمره',
        author: 'assets/images/course/author/02.jpg',
        brand: 'باتا',
        price: '1400.000 تومان',
        id: 8,
    },
];
export default function ProductSlider() {
    return (
     <>
        <div style={{backgroundColor: "#f6f6f6"}} className='py-5'
        >
       <div className="d-flex justify-content-between  align-items-center">
        <div className='custom-slider-btn   '>
        <i class="icofont-curved-left fw-bold"></i>
        <i class="icofont-rounded-right"></i>
        </div>
       <h4 className='rtl mb-3 pb-4 title-slider-custom  pe-5 me-5 '>پرفروش ترین محصولات</h4>
       </div>
          <Swiper
            slidesPerView={2}
            spaceBetween={20}
            loop={true}
            autoplay={
                {
                    delay: 2000,
                    disableOnInteraction: false
                }
            }
            breakpoints={{
              640: {
                slidesPerView: 1,
                spaceBetween: 20,
              },
              768: {
                slidesPerView: 3,
                spaceBetween: 40,
              },
              1024: {
                slidesPerView: 4,
                spaceBetween: 50,
              },
              400: {
                slidesPerView: 1,
                spaceBetween: 20,
              },
            }}
            modules={[Autoplay]}
            className="mySwiper container "        
          >
                <div className="section-wrapper ">
                    <div className="row g-5 justify-content-center row-cols-xl-4 row-cols-lg-3 row-cols-md-2 row-cols-1
                    course-filter">
                        {
                            ProductData.map((product) => (
                                <div className="col  rtl" key={product.id}>
                                    <div className="course-item style-4 " >
                                       <SwiperSlide >
                                       <div className="course-inner hoverSlider shadow-custom  customPElen my-2 mt-2 rtl"  style={{backgroundColor: "#f6f6f6"}}>
                                            <div className="course-thumb ">
                                                <img src={`${product.imgUrl}`} alt={`${product.imgUrl}`} />
                                                <div className='course-category bg-light d-flex justify-content-between p-2 pe-3' >
                                                    <div className="course-cate">
                                                        <a href="#">{product.cate}</a>
                                                    </div>
                                                    <div className="course-reiew" style={{color: "#000"}}>
                                                        <Ratting />
                                                    </div>
                                                </div>
                                            </div>
                                            {/* content */}
                                            <div className="course-content pt-3">
                                                <Link to={`/shop`}><p className='  pe-3' style={{fontSize: "1rem"}}>{product.title}</p></Link>
                                                
                                                <div className="course-footer d-flex border-top-1 justify-content-between align-items-center pe-4">
                                                    <div className='course-author'>
                                                        <Link to="/" className='ca-name ' style={{fontSize: "1rem"}}>{product.brand}</Link>
                                                    </div>
                                                    <div className="course-price pt-3 px-4  text-dark" style={{fontSize: "0.9rem", marginTop: "-0.5rem"}}>
                                                        {product.price}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                       </SwiperSlide>
                                    </div>
                                </div>
                            ))

                        }
                    </div>
                </div>
          </Swiper>
          
        </div>
     </>
      );
}
