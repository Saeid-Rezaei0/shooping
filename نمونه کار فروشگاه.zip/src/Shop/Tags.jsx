import React from 'react'
import { Link } from 'react-router-dom';

const tagsList = [
    { link: "#", text: "کالای دیجیتال" }, 
    { link: "#", text: "موبایل" }, 
    { link: "#", text: "لپ‌تاپ" }, 
    { link: "#", text: "لوازم خانگی" }, 
    { link: "#", text: "مد و پوشاک" }, 
    { link: "#", text: "زیبایی و سلامت" }, 
    { link: "#", text: "کتاب و لوازم التحریر" }, 
    { link: "#", text: "ورزش و سفر" }, 
    { link: "#", text: "کالای دیجیتال" }, 
    { link: "#", text: "خودرو، ابزار و تجهیزات صنعتی" },
    { link: "#", text: "مد و پوشاک" }, 
    { link: "#", text: "لپ‌تاپ" }, 
];

const title = "محبوب‌ترین برچسب‌ها";

function Tags() {
    return (
        <div className='widget widget-tags rtl'>
            <div className="widget-header">
                <h5 className='title'>{title}</h5>
            </div>
            <ul className="widget-wrapper">
                {
                    tagsList.map((val, i)=> (
                    <li key={i}><a href={val.link}>{val.text}</a></li>
                    ))
                }
            </ul>
        </div>
    )
}

export default Tags;
