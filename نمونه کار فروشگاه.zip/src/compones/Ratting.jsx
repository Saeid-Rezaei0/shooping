import React from 'react'

function Ratting() {
  return (
    <span>
        <i className="icofont-ui-rating text-warning"></i>
        <i className="icofont-ui-rating text-warning"></i>
        <i className="icofont-ui-rating text-warning"></i>
        <i className="icofont-ui-rating text-warning"></i>
        <i className="icofont-ui-rating text-warning"></i>
    </span>
  )
}

export default Ratting