import React from 'react';
import { Link } from 'react-router-dom'; // برای استفاده از Link
import Ratting from "../compones/Ratting"
function ProductCard({ Gridelist, products }) { // products را به عنوان ورودی دریافت می‌کنیم
  return (
<div className={`shop-product-wrap row  justify-content-cente ${Gridelist ? "list-group-item" : "list"}`}>
      {
       products.map((product, i)=> (
      <div className="col-lg-4 col-md-6 col-12" key={i}>
          <div className="product-item">
            <div className="product-thumb">
              <div className="pro-thumb">
               <Link to={`/shop/${product.id}`}> <img src={product.img} alt={product.img}  /></Link>
              </div>

              {/* product action link */}

              <div className="product-action-link d-none">
              <Link to={`/shop/${product.id}`}> <i className='icofont-eye'></i></Link> {/* تغییرات در این خط */}
                <a href="#">
                  <i className='icofont-heart'></i>
                </a>
                <Link to={`/shop/${product.id}`}> <i className='icofont-eye'></i></Link> {/* تغییرات در این خط */}
              </div>


              {/* product - content */}
              <div className="product-content" style={{textAlign: "center"}}>
                <h6 className='my-2' style={{fontSize:"0.8rem"}}>
                  <Link to={`/shop/${product.id}`}>{product.name}</Link>
                </h6>
                <p className='text-warning'>
                  <Ratting />
                </p>
                <h6>{product.price}$</h6>
              </div>
            </div>
          </div>
      
      {/* list style */}
        
        </div>
       ))
      }

    </div>
  );
}

export default ProductCard;
