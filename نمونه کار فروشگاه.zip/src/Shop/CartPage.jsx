import React, { useEffect, useState } from 'react'
import PageHeader from '../compones/PageHeader';
import { Link } from 'react-router-dom';
import delTmgUrl from "../assets/images/shop/del.png"
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CheckOutPage from './CheckOutPage';
import ProductSlider from '../home/SliderProduct';
function CartPage() {
    const [cartitem, setcartitem] = useState([]);

    useEffect(() => {
        const storageCartItem = JSON.parse(localStorage.getItem("cart")) || [];
        setcartitem(storageCartItem);
    }, []);

    const calculateitem = (item) => {
        return item.price * item.quantity;
    }

    const handlerIncrese = (item) => {
        const updatedCart = cartitem.map(cartItem => {
            if (cartItem.id === item.id) {
                return { ...cartItem, quantity: cartItem.quantity + 1 };
            }
            return cartItem;
        });
        setcartitem(updatedCart);
        localStorage.setItem("cart", JSON.stringify(updatedCart));
    }

    const handlerdecres = (item) => {
        const updatedCart = cartitem.map(cartItem => {
            if (cartItem.id === item.id && cartItem.quantity > 1) {
                return { ...cartItem, quantity: cartItem.quantity - 1 };
            }
            return cartItem;
        });
        setcartitem(updatedCart);
        localStorage.setItem("cart", JSON.stringify(updatedCart));
    }

    const handlerRemove = (item) => {
        toast.success("محصول با موفقیت حذف شد", {
            position: "top-right",
            style: { textAlign: "right", fontSize: "1.2rem", fontWeight: "bold" }
        });
        const updateproductCart = cartitem.filter(cartItem => cartItem.id !== item.id);
        setcartitem(updateproductCart);
        localStorage.setItem("cart", JSON.stringify(updateproductCart));
    }

    const cartSubmite = cartitem.reduce((total, item) => {
        return total + calculateitem(item);
    }, 0);

    return (
        <div>
            <ToastContainer />
            <PageHeader title={"فروشگاه سبد خرید"} curPage={"سبد خرید"} />

            <div className="shop-cart padding-tb">
    <div className="container">
        <div className="section-wrapper">
            <div className="cart-top rtl">
                <table>
                    <thead>
                        <tr  style={{backgroundColor: "#B1C9EF", color:"#000"}}>
                            <th className='cat-product text-dark'>محصول</th>
                            <th className='cat-price text-dark'>قیمت</th>
                            <th className='cat-quantity text-dark'>تعداد</th>
                            <th className='cat-toprice text-dark'>جمع</th>
                            <th className='cat-edit text-dark'>ویرایش</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                        cartitem.length > 0 ?  cartitem.map((item, index) => (
                                <tr key={index}>
                                    <td className='product-item cat-product'>
                                        <div className="p-thumb ">
                                            <Link to={`/shop/${item.id}`}>
                                                <img src={item.img} alt={item.name} />
                                            </Link>
                                        </div>
                                        <div className="p-content pe-4">
                                            <Link to={`/shop/${item.id}`}>{item.name}</Link>
                                        </div>
                                    </td>
                                    <td className="cat-price">{item.price}</td>
                                    <td className='cat-quantity'>
                                        <div className="cart-plus-minus">
                                            <div className="dec qtybutton" onClick={() => handlerdecres(item)}>-</div>
                                            <input type="text" className='cart-plus-minus-box' name='Quantity' value={item.quantity} readOnly />
                                            <div className="inc qtybutton" onClick={() => handlerIncrese(item)}>+</div>
                                        </div>
                                    </td>
                                    <td className='cat-toprice'>{calculateitem(item)}</td>
                                    <td className='cat-edit'>
                                        <li style={{listStyle: "none", cursor: "pointer"}} onClick={() => handlerRemove(item)}>
                                            <img src={delTmgUrl} alt="Delete" />
                                        </li>
                                    </td>
                                </tr>
                            )):<h3 className='text-center position-relative  mt-5' style={{position:"relative", left:"90%", }}>☹سبد خالی است</h3>
                        }
                    </tbody>
                </table>
            </div>

            {/* سرآغاز بخش سبد خرید */}

            {/* پایان بخش کارت */}

    <div className="container mt-5 rtl" >
    <div className="row">
        <div className="col-12">
            <div className="cart-checkout-box bg-light p-3 rounded shadow-sm">
                <form className='coupon mb-3 d-flex'>
                    <input type="text" className='form-control me-2' id='coupon' placeholder='کد تخفیف ... ' />
                    <button type="submit" className='btn btn-primary' style={{fontSize: "0.8rem"}}>اعمال تخفیف</button>
                </form>
                <form className='cart-checkout d-flex justify-content-between align-items-center'>
                    <button type="submit" className='btn btn-secondary'>به‌روزرسانی سبد خرید</button>
                  
                </form>
            </div>
        </div>

        <div className="col-md-6 col-12 mt-4 ">
            <div className="calculate-shiping bg-light p-3 rounded shadow-sm shadow">
                <h5>محاسبه هزینه ارسال</h5>
                <div className="mb-3">
                    <label htmlFor="country" className="form-label">کشور</label>
                    <select className="form-select" id="country">
                        <option value="ir">ایران (ir)</option>
                        <option value="uk">انگلیس (uk)</option>
                        <option value="bd">بنگلادش</option>
                        <option value="pak">پاکستان</option>
                        <option value="ind">هند</option>
                    </select>
                </div>
                <div className="mb-3 ">
                    <label htmlFor="city" className="form-label">شهر</label>
                    <select className="form-select " id="city">
                        <option value="ir">تهران</option>
                        <option value="uk">لندن</option>
                        <option value="bd">داکا</option>
                        <option value="pak">کراچی</option>
                        <option value="ind">دهلی نو</option>
                    </select>
                </div>
                <div className="mb-3">
                    <label htmlFor="postalcode" className="form-label">کد پستی</label>
                    <input type="text" className='form-control' id='postalcode' placeholder='کد پستی' />
                </div>
                <div className="mb-3">
                    <label htmlFor="postalcode" className="form-label">شماره تلفن</label>
                    <input type="text" className='form-control' id='postalcode' placeholder='شماره تلفن' />
                </div>
                <button type='submit' className='btn btn-primary'>به‌روزرسانی آدرس</button>
            </div>
        </div>

        <div className="col-md-6 col-12 mt-4">
            <div className="cart-overview bg-light p-3 rounded shadow-sm">
                <h5>مجموع سبد خرید</h5>
                <ul className='list-group'>
                    <li className='list-group-item d-flex justify-content-between align-items-center'>
                        <span>مجموع</span>
                        <span className='text-success fw-bold'>${cartSubmite}</span>
                    </li>
                    <li className='my-3 list-group-item d-flex justify-content-between align-items-center'>
                        <span>هزینه ارسال</span>
                        <span className='text-success fw-bold'>رایگان</span>
                    </li>
                    <li className='list-group-item d-flex justify-content-between align-items-center'>
                        <span>مجموع سفارش</span>
                        <span className='text-success fw-bold'>${cartSubmite.toFixed(2)}</span>
                    </li>
                </ul>
            </div>
          <div className="my-4 me-2 " >
          <CheckOutPage />
          </div>
        </div>
    </div>
</div>

        </div>
    </div>
</div>
       <ProductSlider />
        </div>
    )
}

export default CartPage;
