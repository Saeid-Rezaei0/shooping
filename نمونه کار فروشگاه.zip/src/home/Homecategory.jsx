import React from 'react'
import { Link } from 'react-router-dom';

const subTitle = "";
const title = "همه چیز را با ما بخرید";
const btnText = "همین حالا شروع کنید";


const categoryList = [
    {
        imgUrl: 'src/assets/images/category/01.jpg',
        imgAlt: 'دسته بندی rajibraj91 rajibraj',
        iconName: 'icofont-brand-windows',
        title: 'دوربین DSLR',
    },
    {
        imgUrl: 'src/assets/images/category/02.jpg',
        imgAlt: 'دسته بندی rajibraj91 rajibraj',
        iconName: 'icofont-brand-windows',
        title: 'کفش',
    },
    {
        imgUrl: 'src/assets/images/category/03.jpg',
        imgAlt: 'دسته بندی rajibraj91 rajibraj',
        iconName: 'icofont-brand-windows',
        title: 'عکاسی',
    },
    {
        imgUrl: 'src/assets/images/category/04.jpg',
        imgAlt: 'دسته بندی rajibraj91 rajibraj',
        iconName: 'icofont-brand-windows',
        title: 'لباس رسمی',
    },
    {
        imgUrl: 'src/assets/images/category/05.jpg',
        imgAlt: 'دسته بندی rajibraj91 rajibraj',
        iconName: 'icofont-brand-windows',
        title: 'کیف های رنگارنگ',
    },
    {
        imgUrl: 'src/assets/images/category/06.jpg',
        imgAlt: 'دسته بندی rajibraj91 rajibraj',
        iconName: 'icofont-brand-windows',
        title: 'دکوراسیون خانه',
    },
    {
        imgUrl: 'src/assets/images/category/01.jpg',
        imgAlt: 'دسته بندی rajibraj91 rajibraj',
        iconName: 'icofont-brand-windows',
        title: 'دوربین DSLR',
    },
    {
        imgUrl: 'src/assets/images/category/01.jpg',
        imgAlt: 'دسته بندی rajibraj91 rajibraj',
        iconName: 'icofont-brand-windows',
        title: 'دوربین DSLR',
    },
 
];

function Homecategory() {
    return (
        <div className='category-section style-4 padding-tb'>
            <div className="container">
                {/* section-header */}
                <div className="section-header text-center">
                    <span className='subtitle text-primary'>{subTitle}</span>
                    <h2 className='title' style={{fontSize:"1.7rem"}}>{title}</h2>
                </div>

                {/* section-card */}

                <div className="section-wrapper">
                    <div className='row g-4 justify-content-center row-cols-md-4 row-cols-sm-2 row-cols-2'>
                        {
                            categoryList.map((val, i) => (
                                <div className="col" key={i}>
                                    <Link to="/shop" className='category-item'>
                                        <div className='category-inner'>
                                            <div className="category-thumb">
                                                {/* {img-thumb} */}
                                                <img src={val.imgUrl} alt={val.imgUrl} />
                                            </div>

                                            {/* content */}
                                            <div className="category-content">
                                                <div className="cate-icon">
                                                    <i className={`${val.iconName}`}></i>
                                                </div>
                                                <Link to="/shop"><h6>{val.title}</h6></Link>
                                            </div>
                                        </div>
                                    </Link>
                                </div>
                            ))
                        }
                    </div>
                    <div className="text-center mt-3">
                        <Link to="/shop" className='lab-btn '><span>{btnText}</span></Link>
                    </div>
                </div>
            </div>
            
        </div>
    )
}

export default Homecategory